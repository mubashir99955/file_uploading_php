
<h1>Cit Class</h1>
<?php
include'config.php';
$query="SELECT * FROM img_uplaod ";
$result=mysqli_query($mysqli,$query);
?>
<table border="2px solid black">
    <?php
while($row=mysqli_fetch_array($result)){
?> 
    <tr>

        <td><?php echo $row['id'];?></td>
        <td><?php  echo $row['user'];?></td>
        <td><img src="<?php echo $row['img'];?>" height="100px" width="100px"></img></td>
    </tr>

<?php
}
?>
</table>
