<?php
include'config.php';
if(isset($_POST['submit'])){
$image=$_FILES['image'];
// print_r($image);
// print_r ($_FILES['image']);
$user=$_POST['username'];
            $file_name=$_FILES['image']['name'];
            $file_type=$_FILES['image']['type'];
            $file_size=$_FILES['image']['size'];
            $file_tmpName=$_FILES['image']['tmp_name'];
 $filename_explode=explode(".", $file_name);
    //  print_r($filename_explode) ; 
 $to_lower=strtolower(end($filename_explode));

 $file_array=array('jpg','jpeg');
   if(in_array($to_lower,$file_array)){
            $file_destination='images_cit/'.$file_name;
            move_uploaded_file($file_tmpName,$file_destination);
            $query="INSERT INTO `img_uplaod`( `user`, `img`) VALUES ('$user','$file_destination')";
            // print_r($query);
            $result=mysqli_query($mysqli,$query);
            echo"file uploaded";
            header("Location: view_img.php");
   }else {
      echo ' extension not matched';
   }
 }
?>